﻿=== Chroma Cursor Set ===

By: eeveelover64 (http://www.rw-designer.com/user/79116) eeveelovr64@gmail.com

Download: http://www.rw-designer.com/cursor-set/chroma

Author's description:

Cursors I thought were cool & thought, hey why aren't these on RealWorld graphics, & that's why I decide to upload these. (BTW these were NOT made by me, but made by Glimy on Dribbble. Link: https://dribbble.com/shots/3260909-Chroma-Cursors-for-Windows )  My discord also: eeveelover64#0228

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.